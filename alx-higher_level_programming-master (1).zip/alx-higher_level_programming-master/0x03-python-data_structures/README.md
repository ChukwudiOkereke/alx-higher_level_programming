This directory is to study and better understand the use and operation of lists and tuples in the python language. It also contains a task in c in preparation for a technical interview.

