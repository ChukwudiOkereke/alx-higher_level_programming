#!/usr/bin/python3
# print The ascii alphabet in lower case using only one loop and one print
for i in range(97, 123):	 # for every number in the range
    print("{}".format(chr(i)), end='')  # print the ascii char equivalent
