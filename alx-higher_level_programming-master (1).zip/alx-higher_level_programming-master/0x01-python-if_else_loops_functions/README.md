This directory is to understand the use of if, else statements as well as how to use them and loops in python.
