#!/usr/bin/python3


def print_low_alpha():
    for c in 'abcdefghijklmnopqrstuvwxyz':
        print('{}'.format(c), end='')

if __name__ == '__main__':
    print_low_alpha()
