#!/usr/bin/python3
# print all numbers from 0 to 98 in decimal and hexadecimal
for i in range(99):
    print(i, "= 0x{:x}".format(i))
