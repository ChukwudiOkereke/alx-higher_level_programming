#!/usr/bin/python3
# program with function that checks for lowercase
def islower(c):
    return (ord(c) >= 97) and (ord(c) <= 122)
