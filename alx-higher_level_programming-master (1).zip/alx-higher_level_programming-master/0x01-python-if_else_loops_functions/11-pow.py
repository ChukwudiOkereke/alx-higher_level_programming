#!/usr/bin/python3

# function to compute the value of a number raised to a power
# prototype: def pow(a, b); returns the value of a ^ b
# you're not allowed to import any module

def pow(a, b):  # function declaration
    return (a ** b)
