#!/usr/bin/python3

# function to add two integers and return the result
# prototype: def add(a, b), returns the value of a + b
# you are not allowed to import any module

def add(a, b):
    return (a + b)
