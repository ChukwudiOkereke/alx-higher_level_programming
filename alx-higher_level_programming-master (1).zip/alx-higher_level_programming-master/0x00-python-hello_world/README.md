This directory is to explore the concepts of simple python scripts

0-run uses a bash script to run a python script whose name is stored in an environment variable
