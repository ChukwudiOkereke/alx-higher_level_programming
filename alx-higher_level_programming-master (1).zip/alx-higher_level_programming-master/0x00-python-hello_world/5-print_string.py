#!/usr/bin/python3
str = "Holberton School"
print(f"{3 * str}\n{str[:9]}")
