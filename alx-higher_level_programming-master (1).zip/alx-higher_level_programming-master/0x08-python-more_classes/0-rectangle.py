#!/usr/bin/python3

"""Defines a rectangle"""


class Rectangle:
    """defines a simple class"""
    pass
