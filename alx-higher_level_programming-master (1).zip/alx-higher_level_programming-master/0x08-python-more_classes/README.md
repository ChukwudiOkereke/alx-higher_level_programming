This directory goes deeper on the subject of classes and object oriented programming in python.
