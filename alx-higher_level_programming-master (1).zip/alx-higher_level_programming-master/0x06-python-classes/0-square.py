#!/usr/bin/python3

"""Define a class square."""


class Square:
    """Square - simplest class possible"""
    pass
