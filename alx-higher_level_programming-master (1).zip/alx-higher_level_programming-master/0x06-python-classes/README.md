This directory is an introduction to the concept of object oriented programming in python.
It discusses important concepts like python classes, objects, fields etc in python in a project based approach


0-square.py
This script contains an empty class which defines a square
1-square.py
This defines a private attribute size for the Square class
2-square.py
This file based on the previous raises Exceptions for typeErrors and ValueErrors in case of incorrect input
3-square.py
Based on previous, this script adds a function to return the area of the square
4-square.py
Based on previous, this script adds getter and setter functions for the length / size of the square
These fuctions are written in the pythonic way
5-square.py
Based on previous script but adds a print function to print the square with hash characters "#"
6-square.py
Based on previous scripty but class now receives new data in the form of a tuple which is used to print spaces in front of the hashes