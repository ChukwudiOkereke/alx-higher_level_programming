This directory deals with the concept of exceptions, exception handling and their use in error handling in python
