#!/usr/bin/python3
def raise_exception():
    """
    function that raises an exception

    Do not import any module
    """
    raise TypeError
