This repository is to learn to use higher level programming languages such as python to solve software engineering tasks.
The First directory "0x00-python-hello_world" is just an introduction to the language and its uses.
