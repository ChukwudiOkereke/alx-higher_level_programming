#!/usr/bin/python3

# import a variable from the file variable_load_5.py & print its value
if __name__ == '__main__':
    import variable_load_5
    print("{}".format(variable_load_5.a))
