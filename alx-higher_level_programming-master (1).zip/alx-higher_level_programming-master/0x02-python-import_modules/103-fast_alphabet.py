#!/usr/bin/python3
from string import ascii_uppercase
print(ascii_uppercase)
