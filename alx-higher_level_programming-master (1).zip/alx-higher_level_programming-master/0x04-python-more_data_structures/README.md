This directory deals with even more data structures available in python such as sets and dictionaries as well as some functions such as lambda (or anonymous functions), map, filter and reduce (found in functools module) for use in data manipulation and structuring in python.

A set is a data structure which contains only a single occurrence of an element.
A dictionary on the other hand contains key by value pairs. The keys must be an immutable data type.
